package com.quest.etna;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestWebApplication.class, args);
	}

}
